/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: invoice_connectededucation
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `invoice_connectededucation`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `invoice_connectededucation` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `invoice_connectededucation`;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_id` bigint unsigned DEFAULT NULL,
  `list_id` bigint unsigned DEFAULT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` text COLLATE utf8mb4_unicode_ci,
  `attachment_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_mime` varchar(120) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_size` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activities_user_id_foreign` (`user_id`),
  KEY `activities_card_id_foreign` (`card_id`),
  KEY `activities_list_id_foreign` (`list_id`),
  CONSTRAINT `activities_card_id_foreign` FOREIGN KEY (`card_id`) REFERENCES `board_cards` (`id`) ON DELETE SET NULL,
  CONSTRAINT `activities_list_id_foreign` FOREIGN KEY (`list_id`) REFERENCES `board_lists` (`id`) ON DELETE SET NULL,
  CONSTRAINT `activities_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assistant_sales_people`
--

DROP TABLE IF EXISTS `assistant_sales_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `assistant_sales_people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `assistant_sales_people_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assistant_sales_people`
--

LOCK TABLES `assistant_sales_people` WRITE;
/*!40000 ALTER TABLE `assistant_sales_people` DISABLE KEYS */;
INSERT INTO `assistant_sales_people` VALUES
(1,'Rony Sarker','Test','test@gmail.com','1111','2026-04-07 03:24:17','2026-04-07 03:24:17');
/*!40000 ALTER TABLE `assistant_sales_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_card_user`
--

DROP TABLE IF EXISTS `board_card_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_card_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `board_card_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `board_card_user_board_card_id_user_id_unique` (`board_card_id`,`user_id`),
  KEY `board_card_user_user_id_foreign` (`user_id`),
  CONSTRAINT `board_card_user_board_card_id_foreign` FOREIGN KEY (`board_card_id`) REFERENCES `board_cards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `board_card_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_card_user`
--

LOCK TABLES `board_card_user` WRITE;
/*!40000 ALTER TABLE `board_card_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `board_card_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_cards`
--

DROP TABLE IF EXISTS `board_cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_cards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `board_list_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `country_label_id` bigint unsigned DEFAULT NULL,
  `country_label_ids` json DEFAULT NULL,
  `intake_label_id` bigint unsigned DEFAULT NULL,
  `service_area_id` bigint unsigned DEFAULT NULL,
  `service_area_ids` json DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `payment_done` tinyint(1) NOT NULL DEFAULT '0',
  `dependant_payment_done` tinyint(1) NOT NULL DEFAULT '0',
  `is_archived` tinyint(1) NOT NULL DEFAULT '0',
  `position` int unsigned NOT NULL DEFAULT '9999',
  `checked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `board_cards_invoice_unique` (`invoice`),
  KEY `board_cards_board_list_id_foreign` (`board_list_id`),
  CONSTRAINT `board_cards_board_list_id_foreign` FOREIGN KEY (`board_list_id`) REFERENCES `board_lists` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_cards`
--

LOCK TABLES `board_cards` WRITE;
/*!40000 ALTER TABLE `board_cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `board_cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_list_user`
--

DROP TABLE IF EXISTS `board_list_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_list_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `board_list_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `board_list_user_user_id_board_list_id_unique` (`user_id`,`board_list_id`),
  KEY `board_list_user_board_list_id_foreign` (`board_list_id`),
  CONSTRAINT `board_list_user_board_list_id_foreign` FOREIGN KEY (`board_list_id`) REFERENCES `board_lists` (`id`) ON DELETE CASCADE,
  CONSTRAINT `board_list_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_list_user`
--

LOCK TABLES `board_list_user` WRITE;
/*!40000 ALTER TABLE `board_list_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `board_list_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_lists`
--

DROP TABLE IF EXISTS `board_lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_lists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `board_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int unsigned NOT NULL DEFAULT '9999',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `category` tinyint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `board_lists_board_id_foreign` (`board_id`),
  CONSTRAINT `board_lists_board_id_foreign` FOREIGN KEY (`board_id`) REFERENCES `boards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_lists`
--

LOCK TABLES `board_lists` WRITE;
/*!40000 ALTER TABLE `board_lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `board_lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `board_users`
--

DROP TABLE IF EXISTS `board_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `board_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `board_users_user_id_foreign` (`user_id`),
  KEY `board_users_board_id_foreign` (`board_id`),
  CONSTRAINT `board_users_board_id_foreign` FOREIGN KEY (`board_id`) REFERENCES `boards` (`id`) ON DELETE CASCADE,
  CONSTRAINT `board_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_users`
--

LOCK TABLES `board_users` WRITE;
/*!40000 ALTER TABLE `board_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `board_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `boards`
--

DROP TABLE IF EXISTS `boards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `boards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `boards_city_id_foreign` (`city_id`),
  CONSTRAINT `boards_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `boards`
--

LOCK TABLES `boards` WRITE;
/*!40000 ALTER TABLE `boards` DISABLE KEYS */;
/*!40000 ALTER TABLE `boards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branches`
--

DROP TABLE IF EXISTS `branches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `branches` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branches`
--

LOCK TABLES `branches` WRITE;
/*!40000 ALTER TABLE `branches` DISABLE KEYS */;
INSERT INTO `branches` VALUES
(1,'Uttara Branch','2026-04-07 03:23:19','2026-04-07 03:23:19'),
(2,'Dhanmondi Branch','2026-04-07 03:23:26','2026-04-07 03:23:26');
/*!40000 ALTER TABLE `branches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
INSERT INTO `cache` VALUES
('connectedclientmanagement-cache-3950c659687d31fdea6280c67323b70c432478ea','i:1;',1775925104),
('connectedclientmanagement-cache-3950c659687d31fdea6280c67323b70c432478ea:timer','i:1775925104;',1775925104);
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cards`
--

DROP TABLE IF EXISTS `cards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cards`
--

LOCK TABLES `cards` WRITE;
/*!40000 ALTER TABLE `cards` DISABLE KEYS */;
/*!40000 ALTER TABLE `cards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cities` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cities`
--

LOCK TABLES `cities` WRITE;
/*!40000 ALTER TABLE `cities` DISABLE KEYS */;
/*!40000 ALTER TABLE `cities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city_users`
--

DROP TABLE IF EXISTS `city_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `city_users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `city_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `city_users_user_id_foreign` (`user_id`),
  KEY `city_users_city_id_foreign` (`city_id`),
  CONSTRAINT `city_users_city_id_foreign` FOREIGN KEY (`city_id`) REFERENCES `cities` (`id`) ON DELETE CASCADE,
  CONSTRAINT `city_users_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city_users`
--

LOCK TABLES `city_users` WRITE;
/*!40000 ALTER TABLE `city_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `city_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_template_service`
--

DROP TABLE IF EXISTS `contract_template_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_template_service` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_template_id` bigint unsigned NOT NULL,
  `service_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contract_template_service_contract_template_id_service_id_unique` (`contract_template_id`,`service_id`),
  KEY `contract_template_service_service_id_foreign` (`service_id`),
  CONSTRAINT `contract_template_service_contract_template_id_foreign` FOREIGN KEY (`contract_template_id`) REFERENCES `contract_templates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contract_template_service_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_template_service`
--

LOCK TABLES `contract_template_service` WRITE;
/*!40000 ALTER TABLE `contract_template_service` DISABLE KEYS */;
INSERT INTO `contract_template_service` VALUES
(1,1,1,NULL,NULL),
(2,3,1,NULL,NULL);
/*!40000 ALTER TABLE `contract_template_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_templates`
--

DROP TABLE IF EXISTS `contract_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_templates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `service_id` bigint unsigned DEFAULT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contract_templates_service_id_foreign` (`service_id`),
  CONSTRAINT `contract_templates_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_templates`
--

LOCK TABLES `contract_templates` WRITE;
/*!40000 ALTER TABLE `contract_templates` DISABLE KEYS */;
INSERT INTO `contract_templates` VALUES
(1,'Australia Admission Package',NULL,NULL,'contract-templates/0Et3yNO1SWytDMVpYYyyWKs9Ru6NP1okfc2B02gx.pdf',1,'2026-04-07 03:27:30','2026-04-07 03:27:30'),
(2,'UK Bundle Package','Test',NULL,'contract-templates/Z5q2v3iz5LsAHdKxrY5p21mSeQ67p3DwDoTdQq3C.pdf',1,'2026-04-08 02:55:35','2026-04-08 02:55:35'),
(3,'UK Bundle Package','Test',NULL,'contract-templates/rqgknNLTiXykqcmBI6gK6nB2QgEdUFs3hxtmWE99.pdf',1,'2026-04-08 02:55:35','2026-04-08 02:55:35');
/*!40000 ALTER TABLE `contract_templates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_labels`
--

DROP TABLE IF EXISTS `country_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_labels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `country_labels_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_labels`
--

LOCK TABLES `country_labels` WRITE;
/*!40000 ALTER TABLE `country_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `country_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `academic_profile_ssc` text COLLATE utf8mb4_unicode_ci,
  `academic_profile_hsc` text COLLATE utf8mb4_unicode_ci,
  `academic_profile_bachelor` text COLLATE utf8mb4_unicode_ci,
  `academic_profile_masters` text COLLATE utf8mb4_unicode_ci,
  `study_gap` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_funds_for_applicant` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_funds_for_accompanying_members` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moving_abroad_member_count` int unsigned DEFAULT NULL,
  `available_documents` json DEFAULT NULL,
  `english_language_proficiencies` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES
(1,'Syed','Zeehad','syed.zeehad@gmail.com','01612322108','kjdnkj','jknsdfkj','wdkjfn','djfnd',NULL,NULL,NULL,NULL,'[\"ssc_or_o_level_transcript\", \"ssc_or_o_level_certificate\", \"bachelor_transcript\", \"masters_certificate\"]','[]','2026-04-07 03:22:51','2026-04-07 03:33:47'),
(2,'Sharmin','Tahrima','connectedsocials@gmail.com','01330803904','wdc','sfsdf','sd','sds','ds','dsds','sds',1,'[\"hsc_or_a_level_transcript\", \"ssc_or_o_level_transcript\", \"hsc_or_a_level_certificate\", \"ssc_or_o_level_certificate\", \"passport\", \"recommendation_letter\"]','[]','2026-04-07 03:35:23','2026-04-07 03:37:00'),
(3,'Aladin','Connected','test@gmail.com','01612322010','sdcjkn','kjened','klnfj','dkjfn',NULL,NULL,NULL,NULL,'[\"bachelor_transcript\"]','[]','2026-04-08 02:53:43','2026-04-08 04:51:41');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `intake_labels`
--

DROP TABLE IF EXISTS `intake_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `intake_labels` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `intake_labels_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `intake_labels`
--

LOCK TABLES `intake_labels` WRITE;
/*!40000 ALTER TABLE `intake_labels` DISABLE KEYS */;
/*!40000 ALTER TABLE `intake_labels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_items`
--

DROP TABLE IF EXISTS `invoice_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_id` bigint unsigned NOT NULL,
  `service_id` bigint unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT '0.00',
  `line_total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_items_invoice_id_foreign` (`invoice_id`),
  KEY `invoice_items_service_id_foreign` (`service_id`),
  CONSTRAINT `invoice_items_invoice_id_foreign` FOREIGN KEY (`invoice_id`) REFERENCES `invoices` (`id`) ON DELETE CASCADE,
  CONSTRAINT `invoice_items_service_id_foreign` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_items`
--

LOCK TABLES `invoice_items` WRITE;
/*!40000 ALTER TABLE `invoice_items` DISABLE KEYS */;
INSERT INTO `invoice_items` VALUES
(1,1,1,'Admission Package - Australia',20000.00,20000.00,'2026-04-07 03:28:03','2026-04-07 03:28:03'),
(2,2,1,'Admission Package - Australia',20000.00,20000.00,'2026-04-07 03:36:18','2026-04-07 03:36:18'),
(3,3,1,'Admission Package - Australia',20000.00,20000.00,'2026-04-07 12:45:45','2026-04-07 12:45:45'),
(5,4,1,'Admission Package - Australia',20000.00,20000.00,'2026-04-08 03:02:43','2026-04-08 03:02:43'),
(6,5,1,'Admission Package - Australia',20000.00,20000.00,'2026-04-08 03:18:13','2026-04-08 03:18:13'),
(7,6,1,'Admission Package - Australia',20000.00,20000.00,'2026-04-08 04:16:07','2026-04-08 04:16:07'),
(10,7,1,'Admission Package - Australia',20000.00,20000.00,'2026-04-12 08:55:09','2026-04-12 08:55:09');
/*!40000 ALTER TABLE `invoice_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoices`
--

DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoices` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_date` date DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `branch_id` bigint unsigned DEFAULT NULL,
  `customer_id` bigint unsigned DEFAULT NULL,
  `sales_person_id` bigint unsigned DEFAULT NULL,
  `assistant_sales_person_id` bigint unsigned DEFAULT NULL,
  `contract_template_id` bigint unsigned DEFAULT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_evidence_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_value` decimal(12,2) NOT NULL DEFAULT '0.00',
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `preview_sent_at` timestamp NULL DEFAULT NULL,
  `public_token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cash_manager_approved_at` timestamp NULL DEFAULT NULL,
  `cash_manager_approved_by` bigint unsigned DEFAULT NULL,
  `super_admin_approved_at` timestamp NULL DEFAULT NULL,
  `super_admin_approved_by` bigint unsigned DEFAULT NULL,
  `student_signed_at` timestamp NULL DEFAULT NULL,
  `student_signature_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_signature_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `student_signed_by_admin` tinyint(1) NOT NULL DEFAULT '0',
  `student_signed_by_user_id` bigint unsigned DEFAULT NULL,
  `student_photo_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_profile_submitted_at` timestamp NULL DEFAULT NULL,
  `edit_override_user_id` bigint unsigned DEFAULT NULL,
  `locked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  UNIQUE KEY `invoices_public_token_unique` (`public_token`),
  KEY `invoices_branch_id_foreign` (`branch_id`),
  KEY `invoices_customer_id_foreign` (`customer_id`),
  KEY `invoices_sales_person_id_foreign` (`sales_person_id`),
  KEY `invoices_assistant_sales_person_id_foreign` (`assistant_sales_person_id`),
  KEY `invoices_contract_template_id_foreign` (`contract_template_id`),
  KEY `invoices_cash_manager_approved_by_foreign` (`cash_manager_approved_by`),
  KEY `invoices_super_admin_approved_by_foreign` (`super_admin_approved_by`),
  KEY `invoices_student_signed_by_user_id_foreign` (`student_signed_by_user_id`),
  KEY `invoices_edit_override_user_id_foreign` (`edit_override_user_id`),
  CONSTRAINT `invoices_assistant_sales_person_id_foreign` FOREIGN KEY (`assistant_sales_person_id`) REFERENCES `assistant_sales_people` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_cash_manager_approved_by_foreign` FOREIGN KEY (`cash_manager_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_contract_template_id_foreign` FOREIGN KEY (`contract_template_id`) REFERENCES `contract_templates` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_edit_override_user_id_foreign` FOREIGN KEY (`edit_override_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_sales_person_id_foreign` FOREIGN KEY (`sales_person_id`) REFERENCES `sales_people` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_student_signed_by_user_id_foreign` FOREIGN KEY (`student_signed_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `invoices_super_admin_approved_by_foreign` FOREIGN KEY (`super_admin_approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoices`
--

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
INSERT INTO `invoices` VALUES
(1,'INV-20260407-000001','2026-04-07','approved',2,1,1,1,1,'bkash','invoices/payment-evidence/xShnUQy0WsYcyuzylYl2IXSEFyqNV43X5SJwBdfP.pdf',NULL,0.00,20000.00,20000.00,'2026-04-07 03:28:03','YHMZT2BRXgESTEYzWKDz7TY0OsIOzNtO8pXpxNXddinuBWiI',NULL,NULL,'2026-04-07 03:30:53',1,'2026-04-07 03:33:34','deds','172.22.0.1',0,NULL,'invoices/student-photos/pzd7jVFQIiFqYCAk1GwLi82C3H69EsET5R9jOSoi.png','2026-04-07 03:33:47',NULL,'2026-04-07 03:30:53','2026-04-07 03:28:03','2026-04-07 03:33:47'),
(2,'INV-20260407-000002','2026-04-07','approved',2,2,1,1,1,'bkash','invoices/payment-evidence/d8wPB0J3Ra0omCTRPZ8MOviQQMFOmSbnyDHIqO0W.png',NULL,0.00,20000.00,20000.00,'2026-04-07 03:36:18','AxGtipVFeqjuczdAR36aPdprPsp9IRVcrEaJzq0hFjHb1Mwx',NULL,NULL,'2026-04-07 03:37:49',1,'2026-04-07 03:36:57','sdfdf','172.22.0.1',0,NULL,'invoices/student-photos/Dnn1fxblqlZqtGnPMf8UH5NIJA4S64pxmZHHVVtD.png','2026-04-07 03:37:00',NULL,'2026-04-07 03:37:49','2026-04-07 03:36:18','2026-04-07 03:37:49'),
(3,'INV-20260407-000003','2026-04-07','approved',2,2,1,1,1,'bkash',NULL,NULL,0.00,20000.00,20000.00,'2026-04-07 12:45:45','1WNx6vCBdkCLNfsl6e08nixNkkod5fqt2VWEaIuyMydzicbl',NULL,NULL,'2026-04-07 12:47:39',1,'2026-04-07 12:47:31','kjk','172.22.0.1',0,NULL,'invoices/student-photos/6mZrfrSR8VfjaPk2dWnT9BfCEipIZEDCfCDBdYGl.png',NULL,NULL,'2026-04-07 12:47:39','2026-04-07 12:45:45','2026-04-07 12:47:39'),
(4,'INV-20260408-000004','2026-04-08','signed',2,3,1,1,3,'cash',NULL,NULL,0.00,20000.00,20000.00,'2026-04-08 03:02:43','llQvIpkplPqwIbk1fsRyxSMAsardLjyTErLfWnn13iPsoFe1',NULL,NULL,NULL,NULL,'2026-04-08 03:14:43','Aladin','172.22.0.1',0,NULL,'invoices/student-photos/0BJQyRrLanSW0U2paZAfdlpBcVvM3an34rv2YtKs.png','2026-04-08 03:14:59',NULL,NULL,'2026-04-08 03:02:05','2026-04-08 03:14:59'),
(5,'INV-20260408-000005','2026-04-08','preview',2,3,1,NULL,3,'bkash','invoices/payment-evidence/DvZCUcDTjJYXySHMd5xE4yrZmi3oXZUsWaLRFrwf.pdf',NULL,0.00,20000.00,20000.00,'2026-04-08 03:18:13','a5s41R37MCNKhaGwAXNR2ni6liRYB62md1ApYWi97lWmlqsW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-04-08 03:18:13','2026-04-08 03:18:13'),
(6,'INV-20260408-000006','2026-04-08','signed',2,3,1,1,3,'bkash','invoices/payment-evidence/1z4Ywks8FH0MgjzVCMDuKB3KnFKMXgy9pl1PN2O7.pdf',NULL,0.00,20000.00,20000.00,'2026-04-08 04:16:07','c6AzAiZEzYgpyckzuLT9H5xnqQGTTAwdu8hFdYC8yUcCfEo0',NULL,NULL,NULL,NULL,'2026-04-08 04:49:35','dd','172.22.0.1',0,NULL,'invoices/student-photos/agTYJNLzge3tJ5PD8AjXZxxsM73L1b9ySSXNVjsh.png','2026-04-08 04:51:41',NULL,NULL,'2026-04-08 04:16:07','2026-04-08 04:51:41'),
(7,'INV-20260409-000007','2026-04-09','preview',2,3,1,NULL,3,'bkash',NULL,NULL,0.00,20000.00,20000.00,'2026-04-12 08:55:09','mhIpvZDUFHFY9msI6FyErqjRO5nJYt93yyDPruplxVhWs3bZ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-04-09 01:41:11','2026-04-12 08:55:09');
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2025_09_24_040409_create_personal_access_tokens_table',1),
(5,'2025_09_28_072546_create_permission_tables',1),
(6,'2026_01_15_101531_create_tasks_table',1),
(7,'2026_01_15_101542_create_cards_table',1),
(8,'2026_01_15_111716_create_cities_table',1),
(9,'2026_01_15_114630_create_branches_table',1),
(10,'2026_01_19_161041_create_boards_table',1),
(11,'2026_01_21_075711_create_board_lists_table',1),
(12,'2026_01_21_075720_create_board_cards_table',1),
(13,'2026_01_27_055604_create_city_users_table',1),
(14,'2026_01_27_055610_create_board_users_table',1),
(15,'2026_01_28_080726_create_country_labels_table',1),
(16,'2026_01_28_080740_create_intake_labels_table',1),
(17,'2026_01_29_035054_create_activities_table',1),
(18,'2026_02_01_160518_create_board_list_users_table',1),
(19,'2026_02_15_000000_add_category_to_board_lists_table',1),
(20,'2026_02_15_000100_add_attachment_fields_to_activities_table',1),
(21,'2026_02_15_000200_create_board_card_user_table',1),
(22,'2026_02_15_000300_add_payment_done_to_board_cards_table',1),
(23,'2026_02_15_000400_create_service_areas_table',1),
(24,'2026_02_15_000500_add_service_area_id_to_board_cards_table',1),
(25,'2026_02_16_000600_add_is_archived_to_board_cards_table',1),
(26,'2026_02_16_000700_add_multi_labels_and_dependant_payment_to_board_cards_table',1),
(27,'2026_02_17_000900_create_system_settings_table',1),
(28,'2026_02_22_000901_add_allowed_ips_to_users_table',1),
(29,'2026_02_22_000902_drop_system_settings_table',1),
(30,'2026_03_09_000100_create_customers_table',1),
(31,'2026_03_09_000200_create_sales_people_table',1),
(32,'2026_03_09_000300_create_assistant_sales_people_table',1),
(33,'2026_03_09_000400_create_services_table',1),
(34,'2026_03_10_000100_add_address_to_branches_table',1),
(35,'2026_03_10_000200_add_branch_id_to_users_table',1),
(36,'2026_03_10_000300_create_contract_templates_table',1),
(37,'2026_03_10_000400_create_invoices_table',1),
(38,'2026_03_10_000500_create_invoice_items_table',1),
(39,'2026_03_10_000600_remove_city_id_from_branches_table',1),
(40,'2026_03_14_000300_remove_address_fields_from_branches_table',1),
(41,'2026_03_17_000600_drop_quantity_from_invoice_items_table',1),
(42,'2026_03_26_000001_create_contract_template_service_table',1),
(43,'2026_03_27_000100_add_profile_fields_to_customers_table',1),
(44,'2026_03_27_000200_add_customer_profile_submitted_at_to_invoices_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES
(1,'App\\Models\\User',1,'auth_token','47e912ee6a55444c0ce16e1032706aa79c804e980a9baa19934b7c793040bf3a','[\"*\"]','2026-03-31 12:47:46',NULL,'2026-03-31 12:47:29','2026-03-31 12:47:46'),
(2,'App\\Models\\User',1,'auth_token','5558df444bb0271a03bed8bd4a84bf1fdcd636ed8604578f59fb5004a47887e2','[\"*\"]','2026-04-01 01:52:36',NULL,'2026-04-01 01:52:02','2026-04-01 01:52:36'),
(3,'App\\Models\\User',1,'auth_token','4b6fd7141c7f13bdd277f969f3e2aacb79f6957828c253b1e5291b61c76bac35','[\"*\"]','2026-04-02 08:10:11',NULL,'2026-04-02 07:46:17','2026-04-02 08:10:11'),
(4,'App\\Models\\User',1,'auth_token','9765e05499c5c7dc494a1ab681a68a6148d059f8ff88ff5ef79e78f2e2a14fab','[\"*\"]','2026-04-02 13:50:43',NULL,'2026-04-02 13:50:43','2026-04-02 13:50:43'),
(5,'App\\Models\\User',1,'auth_token','513ad51a95757aa30b933cae4899c8945572bdc33f626b8cd7c2ed9cebc0792d','[\"*\"]','2026-04-02 14:59:35',NULL,'2026-04-02 14:59:34','2026-04-02 14:59:35'),
(6,'App\\Models\\User',1,'auth_token','c077735c95c45534589a41f7830c88151a556f3aabd841322297b406218a85eb','[\"*\"]','2026-04-05 13:05:20',NULL,'2026-04-05 13:04:45','2026-04-05 13:05:20'),
(7,'App\\Models\\User',1,'auth_token','15f164345f86c29f1d54a081ec731bb7416c78624f84a36cae12e8e24bff91dc','[\"*\"]','2026-04-07 03:37:49',NULL,'2026-04-07 03:21:12','2026-04-07 03:37:49'),
(8,'App\\Models\\User',1,'auth_token','8c76f39c8c1b78a70cb7e89a6ee9219216f4123ae52f1d827ca915089d94ed94','[\"*\"]','2026-04-07 12:49:13',NULL,'2026-04-07 12:42:55','2026-04-07 12:49:13'),
(9,'App\\Models\\User',1,'auth_token','447ac9cd21cf223dfcdc596320aeaa8771c4b11c50bb7603710182f993f58f05','[\"*\"]','2026-04-08 04:16:07',NULL,'2026-04-08 02:28:19','2026-04-08 04:16:07'),
(10,'App\\Models\\User',1,'auth_token','a27cdae33abb7c398ee074622d6a88054bfe38e1496cae4ac0838185ca01e84c','[\"*\"]','2026-04-08 16:01:54',NULL,'2026-04-08 15:57:40','2026-04-08 16:01:54'),
(11,'App\\Models\\User',1,'auth_token','9064b393145938aad463838c8c5274ec4840aa39a28d46be8db76ab69b0265ca','[\"*\"]','2026-04-08 18:17:07',NULL,'2026-04-08 18:16:51','2026-04-08 18:17:07'),
(12,'App\\Models\\User',1,'auth_token','4280f1117c947e092b58e8e70de151e8b2826b87aacfb0348996bacbf7bef35e','[\"*\"]','2026-04-09 01:43:44',NULL,'2026-04-09 01:37:11','2026-04-09 01:43:44'),
(13,'App\\Models\\User',2,'auth_token','a2c57768c1358bac4a21141c59f8640219411a380d2f04d84e79c3dbe9efcd9f','[\"*\"]','2026-04-09 01:43:04',NULL,'2026-04-09 01:42:57','2026-04-09 01:43:04'),
(14,'App\\Models\\User',1,'auth_token','618ee848419413b17eb991821476ed1b5034e859f49c77d49e749f1f99c377a6','[\"*\"]','2026-04-09 12:17:05',NULL,'2026-04-09 12:17:04','2026-04-09 12:17:05'),
(15,'App\\Models\\User',1,'auth_token','f26daffe7e9bf79364ffbc1bc2ca143ed4f46f7e1759e40e6d32e24b0d041040','[\"*\"]','2026-04-09 18:47:46',NULL,'2026-04-09 18:44:51','2026-04-09 18:47:46'),
(16,'App\\Models\\User',1,'auth_token','3825e1f78a11acb330d82efc9eb58feb07dfd45444f45f06d84a5e2a5280083c','[\"*\"]','2026-04-10 11:33:11',NULL,'2026-04-10 11:33:10','2026-04-10 11:33:11'),
(17,'App\\Models\\User',1,'auth_token','6dfc32c735e7859bdeb7e894a548c286ff1fb256f8447cf4623e7bdc96704ecb','[\"*\"]','2026-04-10 18:51:49',NULL,'2026-04-10 18:26:07','2026-04-10 18:51:49'),
(18,'App\\Models\\User',1,'auth_token','59e0c640549f4248eff5def9413efb276e4edbd95cd701e2521a2d58c63f41d4','[\"*\"]','2026-04-12 08:56:03',NULL,'2026-04-11 16:30:44','2026-04-12 08:56:03');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'superadmin',NULL,'2026-03-31 12:21:31','2026-03-31 12:21:31'),
(2,'admin',NULL,'2026-03-31 12:21:31','2026-03-31 12:21:31');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_people`
--

DROP TABLE IF EXISTS `sales_people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_people` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sales_people_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_people`
--

LOCK TABLES `sales_people` WRITE;
/*!40000 ALTER TABLE `sales_people` DISABLE KEYS */;
INSERT INTO `sales_people` VALUES
(1,'Test','Test','test@gmail.com','00101','2026-04-07 03:24:37','2026-04-07 03:24:37');
/*!40000 ALTER TABLE `sales_people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_areas`
--

DROP TABLE IF EXISTS `service_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_areas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_areas_name_unique` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_areas`
--

LOCK TABLES `service_areas` WRITE;
/*!40000 ALTER TABLE `service_areas` DISABLE KEYS */;
/*!40000 ALTER TABLE `service_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
INSERT INTO `services` VALUES
(1,'Admission Package - Australia','Test',20000.00,'2026-04-07 03:23:55','2026-04-07 03:23:55');
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` int NOT NULL,
  `branch_id` bigint unsigned DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `can_create_users` tinyint NOT NULL DEFAULT '0',
  `allowed_ips` json DEFAULT NULL,
  `permission` tinyint NOT NULL DEFAULT '0',
  `report_notification` tinyint(1) NOT NULL DEFAULT '0',
  `last_login_at` timestamp NULL DEFAULT NULL,
  `account_expires_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_branch_id_foreign` (`branch_id`),
  CONSTRAINT `users_branch_id_foreign` FOREIGN KEY (`branch_id`) REFERENCES `branches` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Super','Admin','superadmin@gmail.com',1,2,NULL,'$2y$12$P0gU2uXFnMVQ/2OXTHApBO/Er9GoKbhJ3NR2.vQ7EfEkC2tbU.PF.',0,'[]',0,0,'2026-04-11 16:30:44',NULL,NULL,'2026-03-31 12:21:31','2026-04-11 16:30:44'),
(2,'Admin','User','admin@gmail.com',2,NULL,NULL,'$2y$12$u6kMkoU49/Nkm5eSctbWZOKPPuucp3.wTqQEL6OB6NLzAfBPPc312',0,NULL,0,0,'2026-04-09 01:42:56',NULL,NULL,'2026-03-31 12:21:31','2026-04-09 01:42:56');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'invoice_connectededucation'
--

--
-- Dumping routines for database 'invoice_connectededucation'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-17  9:03:21
